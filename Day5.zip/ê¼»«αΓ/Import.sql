use [master]
go

create database Shop
go

use Shop
go

create table [Role]
(
Id int identity primary key,
[Name] nvarchar(256)
)
go

create table [User]
(
Id int identity primary key,
Surname nvarchar(256),
[Name] nvarchar(256),
Patronymic nvarchar(256),
[Login] nvarchar(256),
[Password] nvarchar(256),
RoleId int references [Role](Id)
)
go

create table Unit
(
Id int identity primary key,
[Name] nvarchar(256)
)
go

create table Category
(
Id int identity primary key,
[Name] nvarchar(256)
)
go

create table Manufacturer
(
Id int identity primary key,
[Name] nvarchar(256)
)
go

create table [Provider]
(
Id int identity primary key,
[Name] nvarchar(256)
)
go

create table Product
(
Article nvarchar(256) primary key,
[Name] nvarchar(256),
[Description] nvarchar(max),
Price float,
MaxDiscount int,
Discount int,
[Count] int,
Photo nvarchar(256),
UnitId int references Unit(Id),
CategoryId int references Category(Id),
ManufacturerId int references Manufacturer(Id),
ProviderId int references [Provider](Id)
)
go

create table [Status]
(
Id int identity primary key,
[Name] nvarchar(256)
)
go

create table Point
(
Id int identity primary key,
[Address] nvarchar(256)
)
go

create table [Order]
(
Id int identity primary key,
StartDate date,
EndDate date,
Code int,
UserId int references [User](Id),
PointId int references Point(Id),
StatusId int references [Status](Id)
)
go

create table OrderProduct
(
Id int identity primary key,
OrderId int references [Order](Id),
ProductArticle nvarchar(256) references Product(Article),
[Count] int
)
go
